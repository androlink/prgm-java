package TP_java;

import java.util.ArrayList;
import java.util.Scanner;

public class tp2 {

    static Scanner input = new Scanner(System.in);
    static DocBibliotheque l1= new DocBibliotheque("intro a JAVA", "004. 178 K20PM", "j.leblanc", 2015);
    static DocBibliotheque l2= new DocBibliotheque("SDD", "967. 4987 T248O", "M.macin", 2022);
    static MembreBibliotheque m1= new MembreBibliotheque("bob", "pat", 0, "me");
    static MembreBibliotheque m2= new MembreBibliotheque("michel", "nog", 1, "ma");

    public static void main(String[] args) {



        while (true) menu();
    }
    static MembreBibliotheque getMembre(){
        int tmp=0;
        System.out.println("quel membre veux tu");
        System.out.println("1 - membre 1");
        System.out.println("2 - membre 2");
        while(tmp<1||tmp>2) {
            tmp = input.nextInt();
        }

        if(tmp==1)return m1;
        if(tmp==2)return m2;
        return null;
    }
    static DocBibliotheque getLivre(){
        int tmp=0;
        System.out.println("quel doc veux tu");
        System.out.println("1 - livre 1");
        System.out.println("2 - livre 2");
        while(tmp<1||tmp>2) {
            tmp = input.nextInt();
        }

        if(tmp==1)return l1;
        if(tmp==2)return l2;
        return null;
    }

    static void menu() {
        boolean continuer=true;
        int choice;
        do{
            System.out.println("quelle action voulez vous effectuer?");
            System.out.println("0 - information sur un document");
            System.out.println("1 - l'etat d'un document");
            System.out.println("2 - changer l'etat d'un document");
            System.out.println("3 - afficher les information global des livre");
            System.out.println("4 - afficher les information sur un membre");
            System.out.println("5 - quitter");

            choice = input.nextInt();
            input.nextLine();
            int tmp;
            switch (choice){
                case 0:

                    System.out.println(getLivre());
                    break;
                case 1:
                    getLivre().statut();
                    break;
                case 2:
                    changerEtat();
                    break;
                case 3:
                    DocBibliotheque.statuDesLivre();
                    break;
                case 4:
                    System.out.println(getMembre());
                    break;
                case 5:
                    continuer=false;
                    break;
                default:
                    System.out.println("action non reconnue");

            }





        }while(continuer);




    }
    static void changerEtat(){
        boolean continuer=true;
        int choice;
        do{
            System.out.println("quelle action voulez vous effectuer?");
            System.out.println("0 - emprunter");
            System.out.println("1 - deposer");
            System.out.println("2 - ranger");
            System.out.println("3 - reserver");
            System.out.println("4 - dereserver");
            System.out.println("5 - quitter");
            choice = input.nextInt();
            int tmp;
            int tmp2;
            switch (choice){
                case 0:
                    getLivre().emprunt(getMembre());
                    continuer=false;
                    break;
                case 1:
                    getLivre().retour();
                    continuer=false;
                    break;
                case 2:
                    getLivre().rangement();
                    continuer=false;
                    break;
                case 3:
                    getLivre().reservation(getMembre());
                    continuer=false;
                    break;
                case 4:
                    getLivre().dereservation();
                    continuer=false;
                    break;
                case 5:
                    continuer=false;
                    break;
                default:
                    System.out.println("action non reconnue");


            }
        }while(continuer);



    }




    void test() {

    }
}
