package TP_java;

import java.util.ArrayList;
import java.util.Scanner;

public class tp2ArrayList {
    static ArrayList<DocBibliotheque> livre = new ArrayList<>();
    static ArrayList<MembreBibliotheque> membre = new ArrayList<>();
    static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        livre.add(new DocBibliotheque("intro a JAVA", "004. 178 K20PM", "j.leblanc", 2015));
        livre.add(new DocBibliotheque("SDD", "967. 4987 T248O", "M.macin", 2022));
        membre.add(new MembreBibliotheque("bob", "pat", 0, "me"));
        membre.add(new MembreBibliotheque("michel", "nog", 1, "ma"));

        System.out.println(livre);
        System.out.println(membre);
        while (true) menu();
    }

    static void menu() {
        boolean continuer=true;
        int choice;
        do{
            System.out.println("quelle action voulez vous effectuer?");
            System.out.println("0 - information sur un document");
            System.out.println("1 - l'etat d'un document");
            System.out.println("2 - changer l'etat d'un document");
            System.out.println("3 - afficher les information global des livre");
            System.out.println("4 - afficher les information sur un membre");
            System.out.println("5 - quitter");

            choice = input.nextInt();
            input.nextLine();
            int tmp;
            int tmp2;
            switch (choice){
                case 0:
                    tmp=selectionnerLivre();
                    if(tmp!=-1)
                        System.out.println(livre.get(tmp));
                    break;
                case 1:
                    tmp=selectionnerLivre();
                    if(tmp!=-1)
                        livre.get(tmp).statut();
                    break;
                case 2:
                    changerEtat();


            }





        }while(continuer);




    }
    static void changerEtat(){
        boolean continuer=true;
        int choice;
        do{
            System.out.println("quelle action voulez vous effectuer?");
            System.out.println("0 - emprunter");
            System.out.println("1 - deposer");
            System.out.println("2 - ranger");
            System.out.println("3 - quitter");
            choice = input.nextInt();
            int tmp;
            int tmp2;
            switch (choice){
                case 0:
                    tmp=selectionnerMembre();
                    if(tmp!=-1){
                        tmp2=selectionnerLivre();
                        if(tmp2!=-1){
                            livre.get(tmp2).emprunt(membre.get(tmp));
                        }


                    }


                    break;
                case 1:

                    break;
                case 2:



            }





        }while(continuer);



    }
    static int selectionnerLivre(){
        int what = 0;

        do {
            System.out.println("selectionner quelqu'un");
            int count = 1;
            System.out.println("0 - quitter");
            for (DocBibliotheque d : livre) {

                System.out.println(count++ + " - " + d.getName());
            }

            what = input.nextInt() - 1;
        } while (what <= 0 || what > livre.size());
        return what;
    }

    static int selectionnerMembre() {
        int who = 0;
        do {
            System.out.println("selectionner un livre");
            int count = 1;
            System.out.println("0 - quitter");
            for (MembreBibliotheque m : membre) {

                System.out.println(count++ + " - " + m.getNom());
            }

            who = input.nextInt() - 1;
        } while (who <= 0 || who > membre.size());
        return who;
    }

    void test() {

    }
}
