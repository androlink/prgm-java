package TP_java;

public class DocBibliotheque {
    private String titre;
    private String code;        // 000. OOO A000A
    private String auteur;

    static int countEmprunt = 0;
    static int countRetour = 0;
    static int countSectionReservation = 0;

    private MembreBibliotheque emprunteur;
    private MembreBibliotheque reservateur;


    enum etat {
        etagère,
        emprunté,
        pile_de_retour,
        section_de_reservation
    }


    etat ou = etat.etagère;

    private boolean reservé = false;

    /*
    0: etagère
    1: emprunté
    2: pile de retour
     */


    private int annee;


    DocBibliotheque(String titre, String code, String auteur, int annee) {
        this.titre = titre;
        this.annee = annee;
        this.code = code;
        this.auteur = auteur;
    }

    boolean reservation(MembreBibliotheque me) {//initialise une reservation
        boolean test = false;
        if ((!reservé && ou == etat.emprunté) && me != null && me!=emprunteur) {

            reservateur = me;
            reservateur.setLivreReservé(this);
            reservé = true;
            test = true;

            me.setLivreEmprunté(null);
        }
        return test;
    }

    boolean dereservation() {//annule une reservation
        boolean test = false;
        if (reservé) {
            if (ou == etat.section_de_reservation) {
                countSectionReservation--;
                ou = etat.pile_de_retour;
                countRetour++;
            }
            if(reservateur!=null)reservateur.setLivreReservé(null);
            reservateur = null;
            reservé = false;
            test = true;
        }
        return test;
    }//---------------------------------------

    boolean rangement() {//enlève le livre de la pile de retour pour la mettre sur une etagere
        boolean test = false;
        if (ou == etat.pile_de_retour) {
            countRetour--;
            ou = etat.etagère;
            test = true;
        }
        return test;
    }//----------------------------------------

    boolean retour() {//place le livre sur la pile de retour ou dans la section de reservation
        boolean test = false;
        if (ou == etat.emprunté) {

            if (reservé) {
                countSectionReservation++;
                ou = etat.section_de_reservation;

            } else {
                ou = etat.pile_de_retour;

                countRetour++;
            }
            emprunteur.setLivreEmprunté(null);
            emprunteur = null;
            countEmprunt--;
            test = true;
        }
        return test;
    }//---------------------------------------------

    boolean emprunt(MembreBibliotheque me) {//pour emprunter le livre
        boolean test = false;
        if (me != null) {
            if (ou == etat.etagère) {
                countEmprunt++;
                emprunteur = me;emprunteur.setLivreEmprunté(this);
                ou = etat.emprunté;
                test = true;
            }
            if (ou == etat.section_de_reservation && reservateur!=null && me == reservateur) {
                countEmprunt++;
                countSectionReservation--;
                reservé = false;
                emprunteur = me;emprunteur.setLivreEmprunté(this);
                reservateur.setLivreReservé(null);
                ou = etat.emprunté;
                test = true;
                reservateur = null;
            }

        }
        return test;
    }//-----------------------------------------------

    void statut() {
        System.out.println("où: '" + ou + "'\test reservé: '" + reservé + "'");
    }

    static public void statuDesLivre() {
        System.out.println(
                "nombre d'emprunt=" + countEmprunt +
                        ", nombre dans la pile de retour='" + countRetour +
                        ", nombre dans la section de reservation='" + countSectionReservation
                +"\n"
        );

    }

    @Override
    public String toString() {
        return "DocBibliotheque{" +
                "titre='" + titre + '\'' +
                ", code='" + code + '\'' +
                ", auteur='" + auteur + '\'' +
                ", emprunteur=" + emprunteur +
                ", reservateur=" + reservateur +
                ", ou=" + ou +
                ", reservé=" + reservé +
                ", annee=" + annee +
                '}';
    }


    public void setEmprunteur(MembreBibliotheque emprunteur) {
        this.emprunteur = emprunteur;
    }

    public void setReservateur(MembreBibliotheque reservateur) {
        this.reservateur = reservateur;
    }

    public MembreBibliotheque getEmprunteur() {
        return emprunteur;
    }

    public MembreBibliotheque getReservateur() {
        return reservateur;
    }

    void changeName(String name) {
        titre = name;
    }

    void changeCode(String code) {
        this.code = code;
    }

    void changeAuteur(String auteur) {
        this.auteur = auteur;
    }

    void changeAnnee(int annee) {
        this.annee = annee;
    }

    String getName() {
        return titre;
    }

    String getTitre() {
        return titre;
    }

    String getCode() {
        return code;
    }

    String getAuteur() {
        return auteur;
    }

    void printBook() {
        System.out.println("titre: " + titre + " auteur: " + auteur + " code: " + code + " annee: " + annee);
    }
}
