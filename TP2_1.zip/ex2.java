import objet.BienImmobilier;
import objet.Locataire;
import objet.Proprietaire;

import java.util.function.BiConsumer;

public class ex2 {

    public static void main(String[] args) {
        BienImmobilier test = new BienImmobilier(30,14,29.94);
        //BienImmobilier test2 = new BienImmobilier(40,14,34.25);
        Proprietaire george=new Proprietaire("george","qqpar");
        Locataire bob=new Locataire("bob","haha ouai");
        test.setProprietaire(george);
        test.nouveauLocataire(bob);

        System.out.println(test.toString());

    }
    public static int compTaxes(double t1,double t2){
        return (int) (t1-t2);
    }


}
