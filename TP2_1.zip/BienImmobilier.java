package objet;

import static java.lang.Math.round;

public class BienImmobilier {
    public static int reference;
    int id;
    String description;
    int surface;
    /*
    0: libre
    1: location
    2: vente
     */
    int etat=0;
    int tarif;
    double tauxImpot;
    double taxeFonciere;

    Locataire locataire;
    Proprietaire proprietaire;

    public BienImmobilier(){
        id=reference;
        reference++;
    }
    public BienImmobilier(int surface, int tarif, double tauxImpot){
        id=reference; reference++;
        this.surface=surface;
        this.tarif=tarif;
        this.tauxImpot=tauxImpot;
        taxeFonciere=calcTaxeFoncière();
    }
    public void nouveauLocataire(Locataire locataire){
        this.locataire=locataire;
    }
    public void setProprietaire(Proprietaire proprietaire){
        this.proprietaire=proprietaire;
    }
    public double calcTaxeFoncière(){
        taxeFonciere=round((surface*tarif*12)/4 * tauxImpot );
        taxeFonciere/=100;
        return taxeFonciere;
    }
    public double getTaxeFonciere(){
        return taxeFonciere;
    }

    @Override
    public String toString() {
        return "BienImmobilier{" +
                "id=" + id +
                ", description='" + description + '\'' +
                ", surface=" + surface +
                ", etat=" + etat +
                ", tarif=" + tarif +
                ", tauxImpot=" + tauxImpot +
                ", taxeFonciere=" + taxeFonciere +
                ", locataire=" + locataire +
                ", proprietaire=" + proprietaire +
                '}';
    }
}
