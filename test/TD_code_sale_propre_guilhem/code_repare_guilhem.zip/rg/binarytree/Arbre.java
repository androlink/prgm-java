package qualitéDev.com.rg.binarytree;

public class Arbre {
    Branche root;

    public Arbre() {
        root = null;
    }

    public Branche getRoot() {
        return root;
    }

    public void setRoot(Branche root) {
        this.root = root;
    }
}
