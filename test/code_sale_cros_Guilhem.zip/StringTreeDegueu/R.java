package test.StringTreeDegueu;


/**
* @author androlink
*
*
*/
public class R {
char i;
String d;

public R(char i, String d){
this.i =i;
this.d =d;
}

public char getI() {
return i;
}

public String getD() {
return d;
}
}
