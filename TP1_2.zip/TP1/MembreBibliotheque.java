package TP1;

import javax.swing.event.MenuDragMouseEvent;

public class MembreBibliotheque {
    static public int dernierNumeroAbonne =0;
    private int noMemebre;
    private String nom;
    private String prenom;
    private int noTel;
    private String adresse;

    private DocBibliotheque livreEmprunté;
    private DocBibliotheque livreReservé;


    MembreBibliotheque(String nom,String prenom,int noTel,String adresse){
        this.adresse=adresse;
        this.prenom=prenom;
        this.noTel=noTel;
        this.nom=nom;
        noMemebre= dernierNumeroAbonne++;
    }

    public DocBibliotheque getLivreReservé() {
        return livreReservé;
    }

    public void setLivreReservé(DocBibliotheque livreReservé) {
        this.livreReservé = livreReservé;
    }

    public void setLivreEmprunté(DocBibliotheque livreEmprunté) {
        this.livreEmprunté = livreEmprunté;
    }

    public DocBibliotheque getLivreEmprunté() {
        return livreEmprunté;
    }

    @Override
    public String toString() {
        return "MembreBibliotheque{" +
                "noMemebre=" + noMemebre +
                ", nom='" + nom + '\'' +
                ", prenom='" + prenom + '\'' +
                ", noTel=" + noTel +
                ", adresse='" + adresse + '\'' +
                '}';
    }

    public void setNoMemebre(int noMemebre) {
        this.noMemebre = noMemebre;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setNoTel(int noTel) {
        this.noTel = noTel;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public int getNoMemebre() {
        return noMemebre;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public int getNoTel() {
        return noTel;
    }

    public String getAdresse() {
        return adresse;
    }
}
