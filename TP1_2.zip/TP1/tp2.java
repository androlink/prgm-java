package TP1;

public class tp2 {
    public static void main(String[] args) {
        DocBibliotheque livre1=new DocBibliotheque("intro a JAVA","004. 178 K20PM","j.leblanc",2015);
        DocBibliotheque livre2=new DocBibliotheque("SDD","967. 4987 T248O","M.macin",2022);
        MembreBibliotheque m1=new MembreBibliotheque("bob","pat",0,"me");
        MembreBibliotheque m2=new MembreBibliotheque("michel","tap",1,"ma");
        System.out.println(m1);
        System.out.println(m2);

        livre1.emprunt(m1);
        System.out.println("livre1 reservé par "+livre1.getReservateur());
        System.out.println("livre1 emprunté par "+livre1.getEmprunteur());
        System.out.println("le livre1 ce trouve a "+ livre1.ou);
        DocBibliotheque.statuDesLivre();
        System.out.println();
        livre1.reservation(m2);
        System.out.println("livre1 reservé par "+livre1.getReservateur());
        System.out.println("livre1 emprunté par "+livre1.getEmprunteur());
        System.out.println("statut du livre1 "+ livre1.ou);
        DocBibliotheque.statuDesLivre();
        System.out.println();
        livre1.retour();
        System.out.println("livre1 reservé par "+livre1.getReservateur());
        System.out.println("livre1 emprunté par "+livre1.getEmprunteur());
        System.out.println("statut du livre1 "+ livre1.ou);
        DocBibliotheque.statuDesLivre();
        System.out.println();
        livre1.emprunt(m2);
        System.out.println("livre1 reservé par "+livre1.getReservateur());
        System.out.println("livre1 emprunté par "+livre1.getEmprunteur());
        System.out.println("statut du livre1 "+ livre1.ou);
        DocBibliotheque.statuDesLivre();
        System.out.println();
        livre1.reservation(m1);
        System.out.println("livre1 reservé par "+livre1.getReservateur());
        System.out.println("livre1 emprunté par "+livre1.getEmprunteur());
        System.out.println("statut du livre1 "+ livre1.ou);
        DocBibliotheque.statuDesLivre();
        System.out.println();
        livre1.retour();
        System.out.println("livre1 reservé par "+livre1.getReservateur());
        System.out.println("livre1 emprunté par "+livre1.getEmprunteur());
        System.out.println("statut du livre1 "+ livre1.ou);
        DocBibliotheque.statuDesLivre();
        System.out.println();
        livre1.dereservation();

        System.out.println("livre1 reservé par "+livre1.getReservateur());
        System.out.println("livre1 emprunté par "+livre1.getEmprunteur());
        System.out.println("statut du livre1 "+ livre1.ou);
        DocBibliotheque.statuDesLivre();
        System.out.println();

    }
    void test() {

    }
}
