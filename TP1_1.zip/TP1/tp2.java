package TP1;

public class tp2 {
    public static void main(String[] args) {
        DocBibliotheque livre1=new DocBibliotheque("intro a JAVA","004. 178 K20PM","j.leblanc",2015);
        DocBibliotheque livre2=new DocBibliotheque("SDD","967. 4987 T248O","M.macin",2022);
        livre1.emprunt();
        livre1.statut();
        livre1.reservation();
        livre1.statut();
        livre1.retour();
        livre1.statut();
        livre1.reservation();
        livre1.statut();
        livre1.dereservation();
        livre1.statut();
        livre1.reservation();
        livre1.statut();
        livre1.emprunt();
        livre1.statut();
        livre1.retour();
        livre1.statut();
        livre1.dereservation();
        livre1.statut();
        livre1.rangement();
        livre1.statut();
        livre1.reservation();
    }
}
