package TP1;

public class DocBibliotheque {
    private String titre;
    private String code;        // 000. OOO A000A
    private String auteur;

    enum etat {
        etagère,
        emprunté,
        pile_de_retour,
        section_de_reservation
    }

    etat ou = etat.etagère;

    private boolean reservé = false;

    /*
    0: etagère
    1: emprunté
    2: pile de retour
     */


    private int annee;


    DocBibliotheque(String titre, String code, String auteur, int annee) {
        this.titre = titre;
        this.annee = annee;
        this.code = code;
        this.auteur = auteur;
    }

    boolean reservation() {//initialise une reservation
        if(!reservé && ou==etat.emprunté){
            reservé=true;
            return true;
        }
        return false;
    }

    boolean dereservation() {//annule une reservation
        if(reservé){
            if(ou==etat.section_de_reservation)ou=etat.etagère;
            reservé=false;
            return true;
        }
        return false;
    }//---------------------------------------

    boolean rangement() {//enlève le livre de la pile de retour

        if(ou==etat.pile_de_retour){
            if(reservé)
                ou=etat.section_de_reservation;
            else    ou=etat.etagère;
            return true;
        }
            return false;
    }//----------------------------------------

    boolean retour() {//place le livre sur la pile de retour
        if(ou==etat.emprunté){
            ou=etat.pile_de_retour;
            return true;
        }
        return false;
    }//---------------------------------------------

    boolean emprunt() {//pour emprunter le livre
        if(ou==etat.etagère){
            ou=etat.emprunté;
            return true;
        }
        return false;
    }//-----------------------------------------------

    void statut(){
        System.out.println();
        System.out.println("[statut]");
        System.out.println("ou: "+ou+"\treservation: "+reservé);
    }

    void changeName(String name) {
        titre = name;
    }

    void changeCode(String code) {
        this.code = code;
    }

    void changeAuteur(String auteur) {
        this.auteur = auteur;
    }

    void changeAnnee(int annee) {
        this.annee = annee;
    }

    String getName() {
        return titre;
    }

    String getTitre() {
        return titre;
    }

    String getCode() {
        return code;
    }

    String getAuteur() {
        return auteur;
    }

    void printBook() {
        System.out.println("titre: " + titre + " auteur: " + auteur + " code: " + code + " annee: " + annee);
    }
}
