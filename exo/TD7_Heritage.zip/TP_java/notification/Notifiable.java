package exo.TP_java.notification;

import exo.TP_java.DocBibliotheque;

public interface Notifiable {

    boolean docDisponible(DocBibliotheque d);


}
